Zip File Creation Instructions:

  1. Open the appropriate Zip archive on your local machine; it should be located under the "misc" subdirectory of the HTML      manual in question (e.g., "../fileman/docs/pm/misc/fm22_0pm.zip").
      
  2. Delete/remove all files in current Zip archive, leaving an empty shell archive with the same name. 
  
  3. Add all updated/current files and folders to the now empty archive by using wildcards (i.e., "*.*") and checking the        "include subfolders" checkbox; make sure that you navigate to the appropriate directory containing the new/updated           files and folders for this arhive on your local machine when adding the files/folders.

  4. Delete extraneous files and folders:
  
     a. Sort the added files/folders by directory "path" and delete all folder paths with the FrontPage extensions
        (i.e., begin with "_vti_cnf...")

     b. Sort the added files/folders by file "type" and delete any file ending in ".asp" or ".htm" in the main directory.           These files are just redirect files and are not needed in the Zip archive. However, do NOT delete any ".htm" files          under the "common" folder directory.

  5. Close the updated Zip archive
  
  6. Copy the updated Zip archive to the "misc" folder under the appropriate VA FileMan HTML document directory under the
     ../fileman/docs folder on the Bay Pines development Web site (e.g., "../fileman/docs/pm/misc/fm22_0pm.zip").
  
  7. Publish the ../fileman Web site to production. 



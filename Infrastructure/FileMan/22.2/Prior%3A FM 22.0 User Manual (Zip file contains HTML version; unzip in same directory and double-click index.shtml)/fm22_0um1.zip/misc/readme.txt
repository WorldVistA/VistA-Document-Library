============================================================================
Department of Veterans Affairs
VISTA Software Development - San Francisco CIO Field Office
VA FileMan User Manual
Version 22.0 (with updates)
Package Release Date: March 1999
Updated May 2014

============================================================================
Installation Instructions

This manual is maintained and updated on the Product Development (PD) web server.
If you can connect to this serve, it is probably best to
access this manual directly on the PD web server. This way,
you can always access the latest, updated version of the information in the
manual.

However, in an environment where you cannot connect to the Software Service
web server, you can use this manual. A zipped
version of the manual is provided so that it can be downloaded for use on other 
computers.

Installation Instructions

   1. When you download the ZIP file, you should create a separate
      directory for the manual and unzip the ZIP file in the separate
      directory. Once unzipped, the "Table of Contents" page is INDEX.SHTML. 

   2. If you are downloading other manuals in the VA FileMan documentation set
      as well, set up a directory structure on the target disk, as follows:

      ....\dg\ (for Developer's Guide)
      ....\u1\ (for User Manual)
      ....\u2\ (for Advanced User Manual)

      Where "...." is above, you can have any directory path, as long as
      the three directories are placed at the same directory level. Unpack
      each manual in the appropriate directory. This enables cross-manual
      hyperlinks to work.

============================================================================
About this Manual

This online documentation was developed at the Department of Veterans
Affairs (VA). This documentation is for 
VA FileMan 22.0 and includes all updates since VA FileMan 21.0.  

This documentation can be used to assist users,
ADPACs, IRM staff, and developers in becoming familiar with VA FileMan.

============================================================================
Department of Veterans Affairs (VA)
VistA Software Development - Oakland Office of Information and Technology 
Field Office (OITFO)
VA FileMan Developer's Guide
Version 22.2
Package Release Date: August 2016
Updated November 2017

============================================================================
Installation Instructions

This manual is maintained and updated on the Enterprise Program Management Office (EPMO) Web server.
If you can connect to this server, it is probably best to
access this manual directly on the EPMO Web server. This way,
you can always access the latest, updated version of the information in the
manual.

However, in an environment where you cannot connect to the EPMO
Web server, you can use this manual. A zipped
version of the manual is provided so that it can be downloaded for use on other 
computers.

Installation Instructions

   1. When you download the ZIP file, you should create a separate
      directory for the manual and unzip the ZIP file in the separate
      directory. Once unzipped, the "Table of Contents" page is INDEX.SHTML. 

   2. If you are downloading other manuals in the VA FileMan documentation set
      as well, set up a directory structure on the target disk, as follows:

      ....\dg\ (for Developer's Guide)
      ....\u1\ (for User Manual)
      ....\u2\ (for Advanced User Manual)

      Where "...." is above, you can have any directory path, as long as
      the three directories are placed at the same directory level. Unpack
      each manual in the appropriate directory. This enables cross-manual
      hyperlinks to work.

============================================================================
About this Manual

This online documentation was developed at the Department of Veterans
Affairs (VA). This documentation is for 
VA FileMan 22.2 and includes all updates since VA FileMan 21.0.  

This documentation can be used to assist users,
ADPACs, system administrators, and developers in becoming familiar with VA FileMan.

Star Micronics Line Mode Driver 

This driver is a self-installing driver. Simply run the included
file and follow the instructions given, to install your printer.

FAQ is available at www.starmicronics.com

For support e-mail userhelp@star-us.com

or call

732.623.5555